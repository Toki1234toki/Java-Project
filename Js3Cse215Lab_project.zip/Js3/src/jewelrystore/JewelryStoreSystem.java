// jewelrystore/JewelryStoreSystem.java
package jewelrystore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import jewelrystore.inventory.*;
import jewelrystore.customer.Customer;
import jewelrystore.transaction.Transaction;
import jewelrystore.transaction.DefaultDiscountStrategy;
import jewelrystore.transaction.LoyaltyDiscountCalculator;
import jewelrystore.transaction.BulkDiscountCalculator;

public class JewelryStoreSystem {

    private static List<Product> products = new ArrayList<>();
    private static List<Customer> customers = new ArrayList<>();
    private static List<Transaction> transactions = new ArrayList<>();
    private static final String PRODUCT_FILE = "products.txt";
    private static final String CUSTOMER_FILE = "customers.txt";
    private static final String TRANSACTION_FILE = "transactions.txt";

    public static void main(String[] args) {
        loadData();
        createAndShowGUI();
    }

    private static void loadData() {
        loadProducts();
        loadCustomers();
        loadTransactions();
    }

    private static void loadProducts() {
        try (BufferedReader reader = new BufferedReader(new FileReader(PRODUCT_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                String productId = tokenizer.nextToken();
                String name = tokenizer.nextToken();
                double price = Double.parseDouble(tokenizer.nextToken());
                int stock = Integer.parseInt(tokenizer.nextToken());
                String type = tokenizer.nextToken();

                if (type.equals("Ring")) {
                    String material = tokenizer.nextToken();
                    products.add(new Ring(productId, name, price, stock, material));
                } else if (type.equals("Necklace")) {
                    String chainType = tokenizer.nextToken();
                    products.add(new Necklace(productId, name, price, stock, chainType));
                } else if (type.equals("Earring")) {
                    String earringType = tokenizer.nextToken();
                    products.add(new Earring(productId, name, price, stock, earringType));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading products: " + e.getMessage());
        }
    }

    private static void loadCustomers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                String customerId = tokenizer.nextToken();
                String name = tokenizer.nextToken();
                String address = tokenizer.nextToken();
                int loyaltyPoints = Integer.parseInt(tokenizer.nextToken());
                String purchaseHistoryString = "";
                if (tokenizer.hasMoreTokens()){
                    purchaseHistoryString = tokenizer.nextToken();
                }
                String[] purchaseHistoryArray = purchaseHistoryString.split(";");
                List<String> purchaseHistory = new ArrayList<>();
                for (String purchase : purchaseHistoryArray) {
                    if (!purchase.isEmpty()) {
                        purchaseHistory.add(purchase);
                    }
                }
                Customer customer = new Customer(customerId, name, address);
                customer.addLoyaltyPoints(loyaltyPoints);
                for (String purchase : purchaseHistory) {
                    customer.addPurchase(purchase);
                }
                customers.add(customer);
            }
        } catch (IOException e) {
            System.err.println("Error loading customers: " + e.getMessage());
        }
    }
    private static void loadTransactions() {
        try (BufferedReader reader = new BufferedReader(new FileReader(TRANSACTION_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                String transactionId = tokenizer.nextToken();
                String customerId = tokenizer.nextToken();
                String productIdsString = tokenizer.nextToken();
                double totalAmount = Double.parseDouble(tokenizer.nextToken());

                Customer customer = findCustomer(customerId);
                if (customer != null) {
                    Transaction transaction = new Transaction(transactionId, customer);
                    String[] productIds = productIdsString.split(";");
                    for (String productId : productIds) {
                        Product product = findProduct(productId);
                        if (product != null) {
                            try {
                                transaction.addProduct(product);
                            } catch (InsufficientStockException ex) {
                                System.err.println("Error loading product '" + product.getName() + "' for transaction " + transactionId + ": " + ex.getMessage() + ". Skipping this product.");
                                // we could choose to not add the product or even skip the entire transaction
                                // if data integrity is paramount tahole.
                            }
                        }
                    }
                    transactions.add(transaction);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading transactions: " + e.getMessage());
        }
    }
    private static void saveData() {
        saveProducts();
        saveCustomers();
        saveTransactions();
    }

    private static void saveProducts() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(PRODUCT_FILE))) {
            for (Product product : products) {
                writer.println(product.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving products: " + e.getMessage());
        }
    }

    private static void saveCustomers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(CUSTOMER_FILE))) {
            for (Customer customer : customers) {
                writer.println(customer.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving customers: " + e.getMessage());
        }
    }

    private static void saveTransactions() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(TRANSACTION_FILE))) {
            for (Transaction transaction : transactions) {
                writer.println(transaction.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving transactions: " + e.getMessage());
        }
    }

    private static Product findProduct(String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    private static Customer findCustomer(String customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId().equals(customerId)) {
                return customer;
            }
        }
        return null;
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Jewelry Store System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Products", createProductPanel());
        tabbedPane.addTab("Customers", createCustomerPanel());
        tabbedPane.addTab("Transactions", createTransactionPanel());

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private static JPanel createProductPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Price");
        model.addColumn("Stock");
        model.addColumn("Type");
        model.addColumn("Details");

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Product");
        JButton updateButton = new JButton("Update Product");
        JButton deleteButton = new JButton("Delete Product");
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        loadProductsToTable(model);

        addButton.addActionListener(e -> addProductDialog(model));
        updateButton.addActionListener(e -> updateProductDialog(table, model));
        deleteButton.addActionListener(e -> deleteProduct(table, model));

        return panel;
    }

    private static JPanel createCustomerPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Address");
        model.addColumn("Loyalty Points");
        model.addColumn("Purchase History");

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Customer");
        JButton updateButton = new JButton("Update Customer");
        JButton deleteButton = new JButton("Delete Customer");
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        loadCustomersToTable(model);

        addButton.addActionListener(e -> addCustomerDialog(model));
        updateButton.addActionListener(e -> updateCustomerDialog(table, model));
        deleteButton.addActionListener(e -> deleteCustomer(table, model));

        return panel;
    }

    private static JPanel createTransactionPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        model.addColumn("ID");
        model.addColumn("Customer ID");
        model.addColumn("Products");
        model.addColumn("Total Amount");
        model.addColumn("Discounted Amount");

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Create Transaction");
        buttonPanel.add(addButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        loadTransactionsToTable(model);

        addButton.addActionListener(e -> {
            // Retrieve kortesi customer table model when the button is clicked
            DefaultTableModel customerTableModel = (DefaultTableModel) ((JTable) ((JScrollPane) ((JPanel) ((JTabbedPane) panel.getParent()).getComponent(1)).getComponent(0)).getViewport().getView()).getModel();
            createTransactionDialog(customerTableModel, model);
        });

        return panel;
    }

    // Aita helper methods for Product Panel
    private static void loadProductsToTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Product product : products) {
            String details = "";
            if (product instanceof Ring) {
                details = ((Ring) product).getMaterial();
            } else if (product instanceof Necklace) {
                details = ((Necklace) product).getChainType();
            } else if (product instanceof Earring) {
                details = ((Earring) product).getEarringType();
            }
            model.addRow(new Object[]{product.getProductId(), product.getName(), product.getPrice(), product.getStock(), product.getClass().getSimpleName(), details});
        }
    }

    // Aita helper methods for Customer Panel
    private static void loadCustomersToTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Customer customer : customers) {
            model.addRow(new Object[]{customer.getCustomerId(), customer.getName(), customer.getAddress(), customer.getLoyaltyPoints(), String.join(";", customer.getPurchaseHistory())});
        }
    }

    // Aita helper methods for Transaction Panel
    private static void loadTransactionsToTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Transaction transaction : transactions) {
            StringBuilder productIds = new StringBuilder();
            for (Product product : transaction.getProducts()) {
                productIds.append(product.getProductId()).append(";");
            }
            LoyaltyDiscountCalculator loyaltyCalc = new LoyaltyDiscountCalculator(transaction.getCustomer());
            model.addRow(new Object[]{transaction.getTransactionId(), transaction.getCustomer().getCustomerId(), productIds.toString(), transaction.getTotalAmount(), transaction.calculateDiscountedTotal(loyaltyCalc)});
        }
    }

    private static void addProductDialog(DefaultTableModel model) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Add Product");
        dialog.setLayout(new GridLayout(7, 2));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField stockField = new JTextField();
        JComboBox<String> typeComboBox = new JComboBox<>(new String[]{"Ring", "Necklace", "Earring"});
        JTextField detailsField = new JTextField();

        dialog.add(new JLabel("ID:"));
        dialog.add(idField);
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Stock:"));
        dialog.add(stockField);
        dialog.add(new JLabel("Type:"));
        dialog.add(typeComboBox);
        dialog.add(new JLabel("Details:"));
        dialog.add(detailsField);

        JButton addButton = new JButton("Add");
        addButton.addActionListener(e -> {
            try {
                String id = idField.getText();
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                int stock = Integer.parseInt(stockField.getText());
                String type = (String) typeComboBox.getSelectedItem();
                String details = detailsField.getText();

                Product product;
                if (type.equals("Ring")) {
                    product = new Ring(id, name, price, stock, details);
                } else if (type.equals("Necklace")) {
                    product = new Necklace(id, name, price, stock, details);
                } else {
                    product = new Earring(id, name, price, stock, details);
                }

                products.add(product);
                loadProductsToTable(model);
                saveProducts();
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid input. Please check your data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(addButton);
        dialog.pack();
        dialog.setVisible(true);
    }

    private static void updateProductDialog(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a product to update.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Product selectedProduct = products.get(selectedRow);

        JDialog dialog = new JDialog();
        dialog.setTitle("Update Product");
        dialog.setLayout(new GridLayout(7, 2));

        JTextField nameField = new JTextField(selectedProduct.getName());
        JTextField priceField = new JTextField(String.valueOf(selectedProduct.getPrice()));
        JTextField stockField = new JTextField(String.valueOf(selectedProduct.getStock()));
        JComboBox<String> typeComboBox = new JComboBox<>(new String[]{"Ring", "Necklace", "Earring"});
        JTextField detailsField = new JTextField();

        if (selectedProduct instanceof Ring) {
            typeComboBox.setSelectedItem("Ring");
            detailsField.setText(((Ring) selectedProduct).getMaterial());
        } else if (selectedProduct instanceof Necklace) {
            typeComboBox.setSelectedItem("Necklace");
            detailsField.setText(((Necklace) selectedProduct).getChainType());
        } else {
            typeComboBox.setSelectedItem("Earring");
            detailsField.setText(((Earring) selectedProduct).getEarringType());
        }

        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Price:"));
        dialog.add(priceField);
        dialog.add(new JLabel("Stock:"));
        dialog.add(stockField);
        dialog.add(new JLabel("Type:"));
        dialog.add(typeComboBox);
        dialog.add(new JLabel("Details:"));
        dialog.add(detailsField);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(e -> {
            try {
                selectedProduct.setName(nameField.getText());
                selectedProduct.setPrice(Double.parseDouble(priceField.getText()));
                selectedProduct.setStock(Integer.parseInt(stockField.getText()));

                String type = (String) typeComboBox.getSelectedItem();
                if (selectedProduct instanceof Ring && type.equals("Ring")) {
                    ((Ring) selectedProduct).setMaterial(detailsField.getText());
                } else if (selectedProduct instanceof Necklace && type.equals("Necklace")) {
                    ((Necklace) selectedProduct).setChainType(detailsField.getText());
                } else if (selectedProduct instanceof Earring && type.equals("Earring")) {
                    ((Earring) selectedProduct).setEarringType(detailsField.getText());
                }

                loadProductsToTable(model);
                saveProducts();
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid input. Please check your data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(updateButton);
        dialog.pack();
        dialog.setVisible(true);
    }

    private static void deleteProduct(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a product to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        products.remove(selectedRow);
        loadProductsToTable(model);
        saveProducts();
    }
    private static void addCustomerDialog(DefaultTableModel model) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Add Customer");
        dialog.setLayout(new GridLayout(4, 2));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField addressField = new JTextField();

        dialog.add(new JLabel("ID:"));
        dialog.add(idField);
        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Address:"));
        dialog.add(addressField);

        JButton addButton = new JButton("Add");
        addButton.addActionListener(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String address = addressField.getText();

            Customer customer = new Customer(id, name, address);
            customers.add(customer);
            loadCustomersToTable(model);
            saveCustomers();
            dialog.dispose();
        });

        dialog.add(addButton);
        dialog.pack();
        dialog.setVisible(true);
    }

    private static void updateCustomerDialog(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a customer to update.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Customer selectedCustomer = customers.get(selectedRow);

        JDialog dialog = new JDialog();
        dialog.setTitle("Update Customer");
        dialog.setLayout(new GridLayout(4, 2));

        JTextField nameField = new JTextField(selectedCustomer.getName());
        JTextField addressField = new JTextField(selectedCustomer.getAddress());

        dialog.add(new JLabel("Name:"));
        dialog.add(nameField);
        dialog.add(new JLabel("Address:"));
        dialog.add(addressField);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(e -> {
            selectedCustomer.setName(nameField.getText());
            selectedCustomer.setAddress(addressField.getText());
            loadCustomersToTable(model);
            saveCustomers();
            dialog.dispose();
        });

        dialog.add(updateButton);
        dialog.pack();
        dialog.setVisible(true);
    }

    private static void deleteCustomer(JTable table, DefaultTableModel model) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a customer to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        customers.remove(selectedRow);
        loadCustomersToTable(model);
        saveCustomers();
    }

    private static void createTransactionDialog(DefaultTableModel customerTableModel, DefaultTableModel transactionTableModel) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Create Transaction");
        dialog.setLayout(new GridLayout(3, 2));

        JComboBox<String> customerComboBox = new JComboBox<>();
        for (Customer customer : customers) {
            customerComboBox.addItem(customer.getCustomerId());
        }

        JPanel productPanel = new JPanel(new GridLayout(products.size() + 1, 2));
        List<JCheckBox> productCheckBoxes = new ArrayList<>();
        for (Product product : products) {
            JCheckBox checkBox = new JCheckBox(product.getName());
            productCheckBoxes.add(checkBox);
            productPanel.add(checkBox);
            productPanel.add(new JLabel("$" + product.getPrice()));
        }

        dialog.add(new JLabel("Customer:"));
        dialog.add(customerComboBox);
        dialog.add(new JLabel("Products:"));
        dialog.add(productPanel);

        JButton createButton = new JButton("Create");
        createButton.addActionListener(e -> {
            String customerId = (String) customerComboBox.getSelectedItem();
            Customer customer = findCustomer(customerId);
            if (customer != null) {
                String transactionId = "T" + (transactions.size() + 1);
                Transaction transaction = new Transaction(transactionId, customer);
                boolean stockIssue = false; // Flag to track if any stock issue occurred
                for (int i = 0; i < products.size(); i++) {
                    if (productCheckBoxes.get(i).isSelected()) {
                        try {
                            transaction.addProduct(products.get(i));
                        } catch (InsufficientStockException ex) {
                            JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Stock Error", JOptionPane.ERROR_MESSAGE);
                            stockIssue = true;
                            break; // Stop adding products if there's a stock issue
                        }
                    }
                }

                if (!stockIssue) {
                    transactions.add(transaction);
                    loadTransactionsToTable(transactionTableModel);
                    saveTransactions();

                    // Add loyalty points based on the transaction.
                    customer.addLoyaltyPoints(transaction.getTotalAmount());
                    customer.addPurchase(transaction.getTransactionId()); // Add transaction to purchase history

                    // Reload customer table and changes save kortesi. sesh
                    loadCustomersToTable(customerTableModel);
                    saveCustomers();

                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(dialog, "Customer not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(createButton);
        dialog.pack();
        dialog.setVisible(true);
    }
}