package jewelrystore;

public class Main {
    public static void main(String[] args) {
        JewelryStoreSystem.main(args);
    }
}