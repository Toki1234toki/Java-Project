// jewelrystore/transaction/BulkDiscountCalculator.java
package jewelrystore.transaction;

public class BulkDiscountCalculator implements DiscountStrategy {
    @Override
    public double calculateDiscount(double amount) {
        if (amount > 500) {
            return amount * 0.05; // 5% discount for transactions over $500
        }
        return 0.0;
    }
}