// jewelrystore/transaction/LoyaltyDiscountCalculator.java
package jewelrystore.transaction;

import jewelrystore.customer.Customer;

public class LoyaltyDiscountCalculator implements DiscountStrategy {
    private Customer customer;

    public LoyaltyDiscountCalculator(Customer customer) {
        this.customer = customer;
    }

    @Override
    public double calculateDiscount(double amount) {
        if (customer.getLoyaltyPoints() >= 100) {
            return amount * 0.1; // 10% discount if loyalty points are 100 or more
        }
        return 0.0;
    }
}