// jewelrystore/transaction/DiscountStrategy.java
package jewelrystore.transaction;

public interface DiscountStrategy {
    double calculateDiscount(double amount);
}