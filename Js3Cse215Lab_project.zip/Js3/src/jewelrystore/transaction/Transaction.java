// jewelrystore/transaction/Transaction.java
package jewelrystore.transaction;

import jewelrystore.customer.Customer;
import jewelrystore.inventory.InsufficientStockException;
import jewelrystore.inventory.Product;
import java.util.ArrayList;
import java.util.List;

public class Transaction {
    private String transactionId;
    private Customer customer;
    private List<Product> products;

    public Transaction(String transactionId, Customer customer) {
        this.transactionId = transactionId;
        this.customer = customer;
        this.products = new ArrayList<>();
    }

    public String getTransactionId() {
        return transactionId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<Product> getProducts() {
        return products;
    }
    public void addProduct(Product product) throws InsufficientStockException {
        if (product.getStock() > 0) {
            this.products.add(product);
            product.setStock(product.getStock() - 1);
        } else {
            throw new InsufficientStockException("Insufficient stock for product: " + product.getName());
        }
    }
    public double getTotalAmount() {
        double total = 0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }
    public double calculateDiscountedTotal(DiscountStrategy discountStrategy) {
        double total = getTotalAmount();
        double discount = discountStrategy.calculateDiscount(total);
        return total - discount;
    }
    @Override
    public String toString() {
        StringBuilder productIds = new StringBuilder();
        for (Product product : products) {
            productIds.append(product.getProductId()).append(";");
        }
        return transactionId + "," + customer.getCustomerId() + "," + productIds.toString() + "," + getTotalAmount();
    }
}