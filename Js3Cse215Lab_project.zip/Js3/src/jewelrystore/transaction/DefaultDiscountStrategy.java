// jewelrystore/transaction/DefaultDiscountStrategy.java
package jewelrystore.transaction;

public class DefaultDiscountStrategy implements DiscountStrategy {
    @Override
    public double calculateDiscount(double amount) {
        return 0.0; // No discount by default
    }
}