package jewelrystore.inventory;

public class InventoryException extends Exception {
    public InventoryException(String message) {
        super(message);
    }
}