// jewelrystore/inventory/Earring.java
package jewelrystore.inventory;

public class Earring extends Product {
    private String earringType;

    public Earring(String productId, String name, double price, int stock, String earringType) {
        super(productId, name, price, stock);
        this.earringType = earringType;
    }

    public String getEarringType() {
        return earringType;
    }

    public void setEarringType(String earringType) {
        this.earringType = earringType;
    }

    @Override
    public String toString() {
        return super.toString() + "," + "Earring," + earringType;
    }
}