// jewelrystore/inventory/Ring.java
package jewelrystore.inventory;

public class Ring extends Product {
    private String material;

    public Ring(String productId, String name, double price, int stock, String material) {
        super(productId, name, price, stock);
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return super.toString() + "," + "Ring," + material;
    }
}