// jewelrystore/inventory/Necklace.java
package jewelrystore.inventory;

public class Necklace extends Product {
    private String chainType;

    public Necklace(String productId, String name, double price, int stock, String chainType) {
        super(productId, name, price, stock);
        this.chainType = chainType;
    }

    public String getChainType() {
        return chainType;
    }

    public void setChainType(String chainType) {
        this.chainType = chainType;
    }

    @Override
    public String getProductDetails() {
        String baseDetails = super.getProductDetails();
        return baseDetails + ", Type: Necklace and, Chain: " + chainType;
    }

    @Override
    public String toString() {
        return super.toString() + "," + "Necklace," + chainType;
    }
}