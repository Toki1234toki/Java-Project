// jewelrystore/inventory/Product.java
package jewelrystore.inventory;

public class Product {
    private String productId;
    private String name;
    private double price;
    private int stock;

    public Product(String productId, String name, double price, int stock) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public String getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock){
        this.stock = stock;
    }

    public String getProductDetails() {
        return "ID: " + productId + ", Name: " + name + ", Price: " + price;
    }

    @Override
    public String toString() {
        return productId + "," + name + "," + price + "," + stock;
    }
}