// jewelrystore/inventory/InsufficientStockException.java
package jewelrystore.inventory;

public class InsufficientStockException extends InventoryException {
    public InsufficientStockException(String message) {
        super(message);
    }
}