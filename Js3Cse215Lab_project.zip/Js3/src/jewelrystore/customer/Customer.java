// jewelrystore/customer/Customer.java
package jewelrystore.customer;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String customerId;
    private String name;
    private String address;
    private int loyaltyPoints;
    private List<String> purchaseHistory; //flexibily ase

    public Customer(String customerId, String name, String address) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.loyaltyPoints = 0;
        this.purchaseHistory = new ArrayList<>();
    }

    public String getCustomerId() {// private er jonno getset sesh
        return customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    public void addLoyaltyPoints(int points) {
        this.loyaltyPoints += points;
    }

    public void addLoyaltyPoints(double transactionAmount) {
        int points = (int) (transactionAmount * 0.05); // amra 5% of transaction amount nibo
        this.loyaltyPoints += points;
    }

    public List<String> getPurchaseHistory() {
        return purchaseHistory;
    }

    public void addPurchase(String purchaseId) {
        this.purchaseHistory.add(purchaseId);
    }

    @Override
    public String toString() {
        return customerId + "," + name + "," + address + "," + loyaltyPoints + "," + String.join(";", purchaseHistory);
    }
}