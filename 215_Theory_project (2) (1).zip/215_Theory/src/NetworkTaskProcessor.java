// src/NetworkTaskProcessor.java
import java.util.List;

public class NetworkTaskProcessor implements TaskProcessor {

    @Override
    public Result<List<Task>> processTasks(List<Task> tasks) {
        // Simulate network delay
        try {
            Thread.sleep(2000); // 2 seconds delay
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return new Result<>(tasks, "Tasks processed (simulated network).");
    }
}