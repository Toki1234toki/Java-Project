// src/FileTaskProcessor.java
import java.io.*;
import java.util.List;

public class FileTaskProcessor implements TaskProcessor {
    private String filename;

    public FileTaskProcessor(String filename) {
        this.filename = filename;
    }

    @Override
    public Result<List<Task>> processTasks(List<Task> tasks) {
        try {
            saveTasksToFile(tasks);
            return new Result<>(tasks, "Tasks saved successfully to file.");
        } catch (IOException e) {
            return new Result<>(null, "Error saving tasks: " + e.getMessage());
        }
    }

    private void saveTasksToFile(List<Task> tasks) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Task task : tasks) {
                writer.println(task.getDescription() + "," + task.isCompleted());
            }
        }
    }
}