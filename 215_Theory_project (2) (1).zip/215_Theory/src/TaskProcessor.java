// src/TaskProcessor.java
import java.util.List;

public interface TaskProcessor {
    Result<List<Task>> processTasks(List<Task> tasks);
}