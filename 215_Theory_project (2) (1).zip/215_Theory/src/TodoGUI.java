// src/TodoGUI.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

public class TodoGUI {
    private TaskManager taskManager;
    private JList<Task> taskList;
    private DefaultListModel<Task> listModel;
    private JTextField taskInput;

    public TodoGUI() {
        taskManager = new TaskManager();
        listModel = new DefaultListModel<>();
        taskList = new JList<>(listModel);
        taskInput = new JTextField(20);

        JFrame frame = new JFrame("To-Do List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.add(taskInput);

        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String taskDescription = taskInput.getText();
                if (!taskDescription.isEmpty()) {
                    taskManager.addTask(taskDescription);
                    updateTaskList();
                    taskInput.setText("");
                }
            }
        });
        inputPanel.add(addButton);

        JButton completeButton = new JButton("Complete");
        completeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = taskList.getSelectedIndex();
                if (selectedIndex != -1) {
                    taskManager.markTaskCompleted(selectedIndex);
                    updateTaskList();
                }
            }
        });
        inputPanel.add(completeButton);

        JButton processFileButton = new JButton("Save to File");
        processFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processTasks(new FileTaskProcessor("tasks.txt"));
            }
        });
        inputPanel.add(processFileButton);

        JButton processNetworkButton = new JButton("Simulate Network");
        processNetworkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processTasks(new NetworkTaskProcessor());
            }
        });
        inputPanel.add(processNetworkButton);

        JButton loadButton = new JButton("Load");
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    taskManager.loadTasks("tasks.txt");
                    updateTaskList();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Error loading tasks: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        inputPanel.add(loadButton);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(taskList), BorderLayout.CENTER);
        frame.setSize(400, 300);
        frame.setVisible(true);

        //load tasks on application start
        try {
            taskManager.loadTasks("tasks.txt");
            updateTaskList();
        } catch (Exception ex) {
            System.out.println("No tasks file found, or error loading");
        }
    }

    private void processTasks(TaskProcessor processor) {
        SwingWorker<Result<List<Task>>, Void> worker = new SwingWorker<Result<List<Task>>, Void>() {
            @Override
            protected Result<List<Task>> doInBackground() throws Exception {
                return processor.processTasks(taskManager.getTasks());
            }

            @Override
            protected void done() {
                try {
                    Result<List<Task>> result = get();
                    JOptionPane.showMessageDialog(null, result.getMessage());
                    updateTaskList();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error processing tasks: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void updateTaskList() {
        listModel.clear();
        for (Task task : taskManager.getTasks()) {
            listModel.addElement(task);
        }
    }

    public static void main(String[] args) {
        new TodoGUI();
    }
}