// src/Result.java
public class Result<T> {
    private T value;
    private String message;

    public Result(T value, String message) {
        this.value = value;
        this.message = message;
    }

    public T getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }
}